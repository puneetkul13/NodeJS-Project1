
const { sum, divide } = require("./helper");
const total1 = sum(450,751);
const total2 = divide(900,300);
const http = require('http');
const server = http.createServer((req, res )=>{res.end("Hello Ace2Three**")});
server.listen(3000);
console.log("TOTAL1: ",total1);
console.log("TOTAL2: ",total2);