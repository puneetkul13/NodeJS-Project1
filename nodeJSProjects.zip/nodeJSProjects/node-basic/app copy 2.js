
const express = require('express');
const app = express();
app.get('/',(req, res)=>{res.end("hey wha up from express")});
app.listen(3000);