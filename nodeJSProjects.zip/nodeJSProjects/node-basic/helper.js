function sum(a, b){
return a+b;
}
function divide(a, b){
return a/b;
}


module.exports = {
	sum,divide
}
console.log("Process: process")

