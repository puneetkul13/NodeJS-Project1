const express = require("express");
const app = express();
const bodyParser = require('body-parser');
const morgan = require("morgan");
const dataenv = require('dataenv');
const mongoose = require("mongoose");
mongoose.connect(process.env.MONGO_URI, {useNewUrlParse:true}).then(()=>console.log("DB Connected"));
dataenv.config();
const expressValidator = require('express-validator');
const postRoutes = require("./routes/post");
app.use(bodyParser.json());

app.use(morgan("dev"));

app.use("/",postRoutes);

const port = 8080;

app.listen(port,()=>{console.log(`A Node Js API port(Punit): ${port}`);});

mongoose.connection.on("error",err=>{console.log('DB connection error: ${err.message}`)});






