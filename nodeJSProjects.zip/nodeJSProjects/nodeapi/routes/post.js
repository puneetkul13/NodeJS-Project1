const express = require("express");
const {getPosts, createPost} = require("../controller/post");
const validator = require('../validator/index')
const router = express.Router();

router.get("/",postController.getPosts);
router.post("/post", validator.createPostValidator, postController.createPosts);
module.exports = router;
app.use(body-parser);

